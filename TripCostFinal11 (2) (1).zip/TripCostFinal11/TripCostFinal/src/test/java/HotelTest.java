import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HotelTest extends BaseTest {

    @Test(priority = 3)
    public void validateHotelSearch() {
        homePage.searchForCity("Nairobi");
        Assert.assertTrue(driver.getCurrentUrl().contains("hotels.html"));
    }

    @Test(priority = 4)
    public void validateDatesSet() {
        hotelResultsPage.setDates(reader.getCheckIn(), reader.getCheckOut());
        Assert.assertTrue(true);
    }

    @Test(priority = 5)
    public void validateGuestsSet() throws InterruptedException {
        hotelResultsPage.setAdultsAndUpdate(4);
        String summary = driver.findElement(By.id("guestsSummary")).getText();
        Assert.assertTrue(summary.contains("4"));
    }

    @Test(priority = 6)
    public void validateHotelResultsLoaded() {
        hotelResultsPage.clickSearch();
        int count = driver.findElements(By.cssSelector("[data-testid='hotel-name']")).size();
        Assert.assertTrue(count > 0);
    }

    @Test(priority = 7)
    public void validateTopHotelsPrinted() throws Exception {
        hotelResultsPage.printTopHotels(3);
    }

    @Test(priority = 8)
    public void validateHotelNamesNotEmpty() {
        driver.findElements(By.cssSelector("[data-testid='hotel-name']"))
                .forEach(e -> Assert.assertFalse(e.getText().trim().isEmpty()));
    }

    @Test(priority = 9)
    public void validateHotelPricesVisible() {
        int priceCount = driver.findElements(By.cssSelector("[data-testid='price-per-night']")).size();
        Assert.assertTrue(priceCount > 0);
    }
}
