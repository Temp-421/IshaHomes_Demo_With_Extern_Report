import CruisePage.CruisePage;
import HomePage.HomePage;
import HotelResultPage.HotelResultsPage;
import restaurantsPage.Restaurant;
import config.ObjectReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

public class BaseTest {

    protected static WebDriver driver;
    protected static WebDriverWait wait;
    protected static ObjectReader reader;
    protected static HomePage homePage;
    protected static HotelResultsPage hotelResultsPage;
    protected static CruisePage cruisePage;
    protected static Restaurant res;

    @BeforeTest
    public void setup() throws Exception {

        if (driver == null) {   // 🟢 IMPORTANT (prevents multiple browser launch)

            reader = new ObjectReader();
            driver = new ChromeDriver();
            driver.manage().window().maximize();

            wait = new WebDriverWait(driver, Duration.ofSeconds(30));

            homePage = new HomePage(driver);
            hotelResultsPage = new HotelResultsPage(driver);
            cruisePage = new CruisePage(driver);
            res = new Restaurant(driver);

            driver.get(reader.getUrl());
            homePage.waitForPageLoad();
        }
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}