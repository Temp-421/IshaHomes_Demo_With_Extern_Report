package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import utils.DriverManager;

import java.util.List;

public class AdminPage {

    public void goToAdmin() {
        DriverManager.getDriver().findElement(By.xpath("//span[text()='Admin']")).click();
    }

    public void goToJobTitles() {
        DriverManager.getDriver().findElement(By.xpath("//span[text()='Job']")).click();
        DriverManager.getDriver().findElement(By.xpath("//a[text()='Job Titles']")).click();
    }

    public List<WebElement> getJobList() {
        return DriverManager.getDriver()
                .findElements(By.xpath("//div[@class='oxd-table-body']//div[@role='row']"));
    }

    public void clickAdd() {
        DriverManager.getDriver().findElement(By.xpath("//button[normalize-space()='Add']")).click();
    }

    public void addJob(String jobName) {
        DriverManager.getDriver()
                .findElement(By.xpath("//form[@class='oxd-form']//input[1]"))
                .sendKeys(jobName);

        DriverManager.getDriver()
                .findElement(By.xpath("//button[normalize-space()='Save']")).click();
    }

    public void logout() {
        DriverManager.getDriver().findElement(By.xpath("//span[@class='oxd-userdropdown-tab']")).click();
        DriverManager.getDriver().findElement(By.xpath("//a[text()='Logout']")).click();
    }
}