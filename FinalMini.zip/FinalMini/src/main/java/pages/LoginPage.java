package pages;

import org.openqa.selenium.By;
import utils.DriverManager;

public class LoginPage {

    public void openURL() {
        DriverManager.getDriver().get("https://opensource-demo.orangehrmlive.com/");
    }

    public boolean isLoginButtonEnabled() {
        return DriverManager.getDriver()
                .findElement(By.xpath("//button[@type='submit']"))
                .isEnabled();
    }

    public void login(String username, String password) {

        DriverManager.getDriver().findElement(By.name("username")).sendKeys(username);
        DriverManager.getDriver().findElement(By.name("password")).sendKeys(password);
        DriverManager.getDriver().findElement(By.xpath("//button[@type='submit']")).click();
    }
}