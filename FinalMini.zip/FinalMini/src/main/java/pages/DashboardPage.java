package pages;

import utils.DriverManager;

public class DashboardPage {

    public boolean isDashboardLoaded() {
        return DriverManager.getDriver().getCurrentUrl().contains("dashboard");
    }
}