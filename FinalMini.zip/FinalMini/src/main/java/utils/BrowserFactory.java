package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class BrowserFactory {

    public static void initBrowser() {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        DriverManager.setDriver(driver);
    }

    public static void quitBrowser() {
        DriverManager.getDriver().quit();
    }
}