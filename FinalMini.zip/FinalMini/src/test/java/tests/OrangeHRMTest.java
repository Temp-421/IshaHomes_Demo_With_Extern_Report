package tests;

import org.testng.annotations.*;
import pages.*;
import utils.BrowserFactory;

public class OrangeHRMTest {

    LoginPage loginPage;
    DashboardPage dashboardPage;
    AdminPage adminPage;

    @BeforeTest
    public void setup() {
        BrowserFactory.initBrowser();

        loginPage = new LoginPage();
        dashboardPage = new DashboardPage();
        adminPage = new AdminPage();

        loginPage.openURL();
    }

    @Test(priority = 1)
    public void verifyLoginButton() {
        System.out.println("Login button enabled: " + loginPage.isLoginButtonEnabled());
    }

    @Test(priority = 2)
    public void loginTest() {
        loginPage.login("Admin", "admin123");
        System.out.println("Dashboard loaded: " + dashboardPage.isDashboardLoaded());
    }

    @Test(priority = 3)
    public void navigateToJobTitles() {
        adminPage.goToAdmin();
        adminPage.goToJobTitles();
    }

    @Test(priority = 4)
    public void printJobs() {
        adminPage.getJobList().forEach(job -> System.out.println(job.getText()));
    }

    @Test(priority = 5)
    public void addJob() {
        adminPage.clickAdd();
        adminPage.addJob("Automation Tester");
    }

    @Test(priority = 6)
    public void logoutTest() {
        adminPage.logout();
    }

    @AfterTest
    public void tearDown() {
        BrowserFactory.quitBrowser();
    }
}